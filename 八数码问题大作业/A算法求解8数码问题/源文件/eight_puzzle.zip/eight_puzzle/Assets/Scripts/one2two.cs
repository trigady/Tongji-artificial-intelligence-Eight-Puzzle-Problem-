﻿/*************************************************************************
*本函数是用A*算法来实现八数码问题
*1852979李至霖
*1852331雷丁瑞
*2020.4.10-2020.4.25
*本代码写成的脚本需要捆绑在开始按钮上。
**************************************************************************/

using UnityEngine;
using System.Collections;
using System.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine.UI;

//定义了树的节点所需要的变量与方法。
public class dot {
	private int num1, num2, num3, num4, num5, num6, num7, num8, num9, id;
	//num1~9是九个格子内的数值，id是当前节点的身份识别凭证。
	private int nn;//nn代指当前结点所拥有的的子节点数，当nn==0时，说明该结点为叶子结点。
	private List<dot> sons = new List<dot>();//定义dot类的实体列表，用于依次存储各个孩子
	private List<int> ids = new List<int>();//依次存储各个孩子的id序号
	private dot father;//指向到父亲
	private int fnum;//存储当前节点的评价函数值。

	//面向对象的基本get-set操作函数不在赘述
	public int getfnum() {
		return fnum;
	}

	public void setfnum(int fnum) {
		this.fnum = fnum;
	}

	public int getnn() {
		return nn;
	}

	public int getid() {
		return id;
	}

	//构造函数，需要给出所有方格的值、id以及评价函数值
	public dot(int num1, int num2, int num3, int num4, int num5, int num6, int num7, int num8, int num9, int id, int fnum) {
		this.num1 = num1;
		this.num2 = num2;
		this.num3 = num3;
		this.num4 = num4;
		this.num6 = num6;
		this.num7 = num7;
		this.num8 = num8;
		this.num9 = num9;
		this.num5 = num5;
		this.id = id;
		this.fnum = fnum;
		nn = 0;
	}

	public void setfather(dot father) {
		this.father = father;
	}

	//向当前节点添加一个子节点，构造子节点的同时进行了父子连接，nn自增
	public void addson(int num1, int num2, int num3, int num4, int num5, int num6, int num7, int num8, int num9, int id, int fnum) {
		dot son = new global::dot(num1, num2, num3, num4, num5, num6, num7, num8, num9, id, fnum);
		son.setfather(this);
		this.nn = this.nn + 1;
		sons.Add(son);
		ids.Add(id);
	}

	//连接到指定id的儿子，如果id错误，则返回当前节点自身
	public dot toson(int id) {
		if (this.nn == 0) {
			return this;
		}
		int haha = this.id2num(id);
		if (haha == -1) {
			return this;
		}
		return sons[haha];
	}

	//根据id查找是当前节点的第几个儿子，若不是儿子则返回-1
	public int id2num(int id) {
		for (int i = 0; i < this.nn; i = i + 1) {
			if (this.ids[i] == id) {
				return i;
			}
		}
		return -1;
	}

	//连接到当前节点的第num个儿子，若该儿子不存在，则返回当前节点自身
	public dot tosonbynum(int num) {
		if (this.nn == 0) {
			return this;
		}
		if (num < 0) {
			return this;
		}
		if (num >= this.nn) {
			return this;
		}
		return sons[num];
	}

	//以列表的形式返回九个num的值
	public List<int> getnum() {
		List<int> ans = new List<int>();
		ans.Add(num1);
		ans.Add(num2);
		ans.Add(num3);
		ans.Add(num4);
		ans.Add(num5);
		ans.Add(num6);
		ans.Add(num7);
		ans.Add(num8);
		ans.Add(num9);
		return ans;
	}
};

//该类继承自MonoBehavior，用于搭载在开始按钮上作为自定义脚本实现展示部分的绝大部分功能
public class one2two : MonoBehaviour {

	dot head;//用于记录A*搜索树的根结点
	bool flag = true;//用于判定当前处理的结点是否为根结点
	int[] levelnum = new int[100];//用于记录每一层的节点数，以便计算开始位置，使得结点居中排布
	int maxlevel = 0;//用于记录搜索树层数

	List<int> ansid = new List<int>();//用于记录正确路径所包含节点的id

	//该函数用于读取out_tree.txt，同时生成并存储整个A*搜索树
	void ReadFile() {
		for(int ii = 0; ii < 100; ii++) {
			levelnum[ii] = 0;
		}
		dot p;
		List<int> fids;
		int dos, i, level = 0;
		string line;
		char[] cc;
		int fnum;
		List<int> nums;
		int thisid = 0;
		//这里在逐行逐节点读取文件
		try {
			using (StreamReader sr = new StreamReader(".//out_tree.txt")) {
				// 从文件读取并显示行，直到文件的末尾 
				while ((line = sr.ReadLine()) != null) {
					fids = new List<int>();
					cc = line.ToCharArray();
					dos = 0;
					for (i = 0; cc[i] != '>'; i++) {
						if (cc[i] == '<') {
							continue;
						}
						if (cc[i] == ' ') {
							if (cc[i - 1] == '<') {
								continue;
							}
							if (cc[i + 1] == '>') {
								thisid = dos;
								i = i + 2;
								break;
							}
							fids.Add(dos);
							dos = 0;
						} else {
							dos = dos * 10 + (int)(cc[i] - '0');
						}
					}
					nums = new List<int>();
					for (int j = 0; j < 9; j++) {
						i = i + 1;
						nums.Add((int)(cc[i] - '0'));
					}
					fnum = 0;
					i++;
					for (; cc[i] == ' ' || cc[i] == '*'; i++) ;
					for (; cc[i]!=' '; i++) {
						fnum = fnum * 10 + (int)(cc[i] - '0');
					}
					//print(fnum);
					if (flag) {
						flag = false;
						head = new dot(nums[0], nums[1], nums[2], nums[3], nums[4], nums[5], nums[6], nums[7], nums[8], thisid, fnum);
					} else {
						p = head;
						level = 0;
						foreach (int j in fids) {
							if (j == 0) {
								continue;
							}
							p = p.toson(j);
						}
						level = fids.Count;
						if (level > this.maxlevel) {
							this.maxlevel = level;
						}
						levelnum[level]++;
						p.addson(nums[0], nums[1], nums[2], nums[3], nums[4], nums[5], nums[6], nums[7], nums[8], thisid, fnum);
					}
					nums.Clear();
					fids.Clear();
					cc = new char[100];
				}
			}
		} catch (Exception e) {
			Debug.Log("The file could not be read:1");
		}

		//这里在逐个id读取正确路径
		try {
			using (StreamReader sr = new StreamReader(".//out.txt")) {
				// 从文件读取并显示行，直到文件的末尾
				line = sr.ReadLine();
				cc = line.ToCharArray();
				dos = 0;
				for(int j = 0; cc[j] != '>'; j++) {
					if(cc[j]==' ') {
						ansid.Add(dos);
						dos = 0;
					}else {
						dos = dos * 10 + (int)(cc[j] - '0');
					}
				}
			}
		} catch (Exception e) {
			Debug.Log("The file could not be read:2");
		}
	}

	//该函数用于判定当前节点是否在正确路径上，若在则返回下一个正确路径结点，若不在则返回-1。
	int findans(int id) {
		for(int mnb = 0; mnb < ansid.Count - 1; mnb++) {
			if (ansid[mnb] == id) {
				return mnb;
			}
		}
		return -1;
	}

	//该函数用于在pos位置绘制一个数值组合为nums，评价函数值为fnum的节点。
	void MakeNode(List<int> nums,Vector3 pos,int fnum) {

		GameObject go;
		Material mt = null;
		Vector3 v3;

		List<Vector3> ls = new List<Vector3>();
		ls.Add(pos + new Vector3(-0.6f, 0.6f, 0));
		ls.Add(pos + new Vector3(0, 0.6f, 0));
		ls.Add(pos + new Vector3(0.6f, 0.6f, 0));
		ls.Add(pos + new Vector3(-0.6f, 0, 0));
		ls.Add(pos + new Vector3(0, 0, 0));
		ls.Add(pos + new Vector3(0.6f, 0, 0));
		ls.Add(pos + new Vector3(-0.6f, -0.6f, 0));
		ls.Add(pos + new Vector3(0, -0.6f, 0));
		ls.Add(pos + new Vector3(0.6f, -0.6f, 0));

		for(int k=0; k<9; k++) {
			mt = Resources.Load("num" + nums[k]) as Material;
			v3 = ls[k];
			go = GameObject.CreatePrimitive(PrimitiveType.Cube);
			go.GetComponent<Transform>().position = v3;
			go.transform.localScale = new Vector3(0.5f, 0.5f, 0.01f);
			go.transform.Rotate(new Vector3(0, 180, 0));
			go.GetComponent<Renderer>().material = mt;

		}

		go = new GameObject();
		go.GetComponent<Transform>().position= (pos + new Vector3(-0.6f, -0.9f, 0));
		go.GetComponent<Transform>().localScale = new Vector3(0.04f, 0.04f, 0);
		go.AddComponent<MeshRenderer>();
		go.AddComponent<TextMesh>().fontSize = 100;
		go.GetComponent<TextMesh>().text = "f(n)=" + fnum;
	}

	//这里定义了一些绘制图形中相对位置的基本量
	const float deta = 3.0f;
	float[] levels = new float[100];
	Vector3 loo = new Vector3(0, 0.9f, 0);

	//该函数用于以递归的方式，以DFS的方式遍历搜索树，并调用MakeNode函数画出结点，同时父子连线
	Vector3 MakeTree(dot p,int level) {
		int erw;

		GameObject l;

		Vector3 aa = new Vector3((float)levels[level], -(float)level * deta, 0f), bb;

		int temp = p.getnn();
		MakeNode(p.getnum(), aa, p.getfnum());
		levels[level] = levels[level] + 2.5f;
		erw = findans(p.getid());
		for(int i = 0; i < temp; i++) {
			bb = MakeTree(p.tosonbynum(i), level + 1);
			l = GameObject.CreatePrimitive(PrimitiveType.Cube);
			l.transform.position = (aa + bb) / 2;
			l.transform.localScale = new Vector3(0.05f, Vector3.Distance(aa - loo, bb + loo), 0.01f);
			l.transform.Rotate(new Vector3(0, 0, -(float)(Math.Atan2((double)(aa.x - bb.x),(double)( aa.y - bb.y - 1.8f)) * 180 / Math.PI)));
			if(erw!=-1 && ansid[erw + 1] == p.tosonbynum(i).getid()) {
				l.GetComponent<MeshRenderer>().material.color = Color.red;
			}else {
				l.GetComponent<MeshRenderer>().material.color = Color.white;
			}
		}
		return aa;
	}

	// Use this for initialization
	void Start () {

	}

	// 该函数是unity生命周期函数的一环，会实时循环执行，用于实现对键盘按键的监听。
	void Update () {

		float speed = 30.0f;


	GameObject go = GameObject.Find("MainCamera");
		if (Input.GetKey(KeyCode.W)) {
			go.transform.Translate(Vector3.up * Time.deltaTime * speed);
		}
		if (Input.GetKey(KeyCode.S)) {
			go.transform.Translate(Vector3.down * Time.deltaTime * speed);
		}
		if (Input.GetKey(KeyCode.A)) {
			go.transform.Translate(Vector3.left * Time.deltaTime * speed);
		}
		if (Input.GetKey(KeyCode.D)) {
			go.transform.Translate(Vector3.right * Time.deltaTime * speed);
		}
		if (Input.GetKey(KeyCode.Q)) {
			go.transform.Translate(Vector3.forward * Time.deltaTime * speed * 0.2f);
		}
		if (Input.GetKey(KeyCode.E)) {
			go.transform.Translate(Vector3.back * Time.deltaTime * speed * 0.2f);
		}
		if (Input.GetKeyDown(KeyCode.Escape)){
			Debug.Log("退出");
			Application.Quit();
		}
	}

	//该函数用于读取node.txt，返回生成节点数与扩展节点数
	private List<int> readnode() {
		List<int> ans = new List<int>();
		int temp = 0;
		char[] cc;
		try {
			using (StreamReader sr = new StreamReader(".//node.txt")) {
				cc = sr.ReadLine().ToCharArray();
				for (int i = 1; ; i++) {
					if (cc[i] == ' ') {
						ans.Add(temp);
						temp = 0;
						continue;
					} else if (cc[i] == '>') {
						ans.Add(temp);
						break;
					}
					temp = temp * 10 + (int)(cc[i] - '0');
				}
			}
		} catch (Exception e) {
			Debug.Log("The file could not be read:3");
		}
		return ans;
	}

	//该函数系监听函数，当点击开始按钮后，会开始统筹调用其他函数
	private void OnMouseDown() {
		//这里用于记录运行时间
		System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();

		stopwatch.Start();
		System.Diagnostics.Process.Start("puzzle.exe").WaitForExit();
		stopwatch.Stop();
		TimeSpan timeSpan = stopwatch.Elapsed;
		DateTime dtime = DateTime.MinValue.Add(timeSpan);


		//这里用于切换camera时间
		Vector3 pos = new Vector3(0, 0, -10);
		GameObject go = GameObject.Find("MainCamera");
		go.GetComponent<Transform>().position = pos;

		//这里用于将开始界面隐藏
		GameObject.Find("Cube_back").SetActive(false);
		GameObject.Find("Cube_first").GetComponent<Transform>().localScale = new Vector3(0, 0, 0);

		//这里用于实现三个挂件的显示
		List<int> node = readnode();

		GameObject.Find("Text").GetComponent<Text>().text = "运行时间：" + string.Format(@"{0:hh\mm\:ss}", timeSpan);
		GameObject.Find("Text").GetComponent<RectTransform>().sizeDelta = new Vector2(200, 50);

		GameObject.Find("Text2").GetComponent<Text>().text = "扩展结点个数：" + node[0] + "个";
		GameObject.Find("Text2").GetComponent<RectTransform>().sizeDelta = new Vector2(200, 50);

		GameObject.Find("Text3").GetComponent<Text>().text = "生成结点个数：" + node[1] + "个";
		GameObject.Find("Text3").GetComponent<RectTransform>().sizeDelta = new Vector2(200, 50);

		//这里开始读取文档并生成树。
		ReadFile();
		for (int i = 0; i <= maxlevel; i++) {
			levels[i] = -((float)(levelnum[i] - 1) * 2.5f) * 0.5f;
		}
		MakeTree(head, 0);

		//这里用于删除调用.exe所生成三个传递文件，以免占用过多用户内存
		File.Delete("out.txt");
		File.Delete("out_tree.txt");
		File.Delete("node.txt");
	}
}