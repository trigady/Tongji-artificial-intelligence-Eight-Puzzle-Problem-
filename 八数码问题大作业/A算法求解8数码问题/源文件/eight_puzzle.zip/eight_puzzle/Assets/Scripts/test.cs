﻿using UnityEngine;
using System.Collections;

public class test : MonoBehaviour {
	// Use this for initialization
	void Start() {
		Debug.Log("开始了");

	}

	// Update is called once per frame
	void Update() {

	}
}
