﻿
/*************************************************************************
*本函数是用A*算法来实现八数码问题
*1852979李至霖
*1852331雷丁瑞
*2020.4.10-2020.4.25
**************************************************************************/

/*
头文件说明：
vector:存储open表的数据结构
map:存储closed_table表的数据结构
*/
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <vector> 
#include <algorithm> 
#include <map>
using namespace std;

typedef int twoD_arr[4][4];//定义二维数
int way;//选择的函数，0为H，1为H1，2为H2，3为H3
int sum_node=0;//生成的节点数
int expansion_node=0;//扩展节点数

//定义节点
class DigitNode {
public:
	int oneD_arr;//一维数字表示的序列号
	int d;    //路径深度depth,相当于f=g+h中的g
	int h;    //评价值func,相当于f=g+h中的h
	int order;  //当前节点序号
	int parent;  //父节点序号

	//构造函数
	DigitNode(int oneD_arr, int d, int h, int order, int parent) :oneD_arr(oneD_arr), d(d), h(h), order(order), parent(parent) {}

	//重载<和==操作符,使得两个节点可以直接用<和==进行比较
	bool operator < (const DigitNode& s)const {
		return(oneD_arr < s.oneD_arr);
	}
	bool operator == (const DigitNode& s)const {
		return (oneD_arr == s.oneD_arr); 
	}
};


static multimap<int, DigitNode> open_table;//键值对的open表,先可以简单地认为是一个未搜索节点的表,因为节点可能重复，所以用multimap这个容器
static map<DigitNode, int> table_open;   //值键对的open表
/*
双map表，在查找元素的时候，不用遍历，可以用lower_bound()函数找相应的序号
*/
static map<int, bool>closed_table;       //closed_table表,先可以简单认为是一个已完成搜索节点的表（即已经将下一个状态放入open表内）
static vector <DigitNode> route;         //保存closed_table表的路径
static vector <int> expansion;         //保存扩展节点的路径
/*
open表和close表中的元素在一定规则下可以相互转化，最终搜到解
	1：对于新添加的节点S（open表和close表中均没有这个状态），S直接添加到open表中
	2：对于已经添加的节点S（open表和close表中已经有这个状态），若在open表中，与原来状态S0的f（n）比较，取最小的一个若在close表中，那就分成两种情况，
第一种，close表中的状态S0的f（n）大于S的，不做修改；第二种，S0的f（n）小于S的，那就需要将close表中的S0的f（n）更新，同时将该状态移入到open表中
	3：下一个搜索节点的选择问题，选取open表中f（n）值最小的状态作为下一个待搜索节点
	4：每次需要将待搜索的节点下一个所有的状态按照规则1和2更新open表，close表，搜索完节点后，移到close表中
*/


bool final(const int& a, const int& s);         //检查是否到达目标路径
bool achievable(const int& order, const int& tar); //检查是否有解
int H(int curOrder, int tarOrder);              //启发函数0
int H1(int curOrder, int tarOrder);              //启发函数1
int H2(int curOrder);                            //启发函数2
int H3(int curOrder, int tarOrder);              //启发函数3
int Func(const DigitNode& a);                    //返回状态的Func=g+h值
int TwoD_OneD(const twoD_arr& s);                //二维数组转换为一维数字
void OneD_TwoD(int a, twoD_arr s);               //一维数字转换为二维数组
void inPut(twoD_arr s);                          //输入初始序列和目标序列
void findRoute(int parent, int size, int step);  //找到最优解的路径
int body(const int& first, const int& last);      //运行A*函数算法主体



//容器vector中元素的去重
vector<int> unique_element_in_vector(vector<int> v) {
	vector<int>::iterator vector_iterator;
	sort(v.begin(), v.end());
	vector_iterator = unique(v.begin(), v.end());
	if (vector_iterator != v.end()) {
		v.erase(vector_iterator, v.end());
	}
	return v;
}



//一维数字转换为二维数组
void OneD_TwoD(int a, twoD_arr s)
{
	for (int i = 3; i >= 1; i--)
		for (int j = 3; j >= 1; j--)
		{
			s[i][j] = a % 10;
			a /= 10;
		}
}
//将二维数组转换为一维数字
int TwoD_OneD(const twoD_arr& s) {
	int a = 0;
	for (int i = 1; i <= 3; ++i)
		for (int j = 1; j <= 3; ++j)
			a = a * 10 + s[i][j];
	return a;
}
//返回DigitNode的评估值，f=g+h
int Func(const DigitNode& a) {
	return a.d + a.h;
}
//判断是否已达到目标
bool final(const int& order, const int& target) {
	return(H(order, target) == 0);
}

//判断是否有解，存在一个判定定理：八数码问题可解当且仅当初态数字（除空格）的逆序数之和与终态的逆序数之和奇偶性一致
bool achievable(const int& order, const int& tar) {
	int order_num = 0, target_num = 0;
	twoD_arr orr, trr;
	OneD_TwoD(order, orr);
	OneD_TwoD(tar, trr);
	for (int i = 0; i < 9; i++)
	{
		//找第i+1个元素后面所有的非0元素，如果元素比它小，那就对应逆序数+1
		for (int j = 0; j < i; j++)
		{
			//row=位置值/n,cloumn=位置值%n
			if ((orr[i / 3 + 1][i % 3 + 1] != 0) && (orr[j / 3 + 1][j % 3 + 1] != 0) && (orr[i / 3 + 1][i % 3 + 1] < orr[j / 3 + 1][j % 3 + 1])) order_num++;
			if ((trr[i / 3 + 1][i % 3 + 1] != 0) && (trr[j / 3 + 1][j % 3 + 1] != 0) && (trr[i / 3 + 1][i % 3 + 1] < trr[j / 3 + 1][j % 3 + 1])) target_num++;
		}
	}
	return  (order_num & 1) == (target_num & 1);
}

//启发函数0，原理：找当前状态与目标状态的位置不同，且非0数字的个数
int H(int curOrder, int tarOrder)
{
	int num = 0;
	for (int i = 0; i < 9; i++) {
		if ((curOrder % 10 != tarOrder % 10))
			num++;
		curOrder /= 10;
		tarOrder /= 10;
	}
	return num;
}

//启发函数1
int H1(int curOrder, int tarOrder) {
	//找当前状态要移动到目标的最短路径，返回所有状态的最短路径之和
	int num = 0;
	int cur[9], tar[9];//引入一种新的数组，这个数组的下标值代表的是元素位置值0-8
	int order = curOrder, target = tarOrder;
	for (int i = 8; i >= 0; i--) {//移动的最小步骤不只是相减，如6到9只需移动一位
		cur[order % 10] = i; 
		tar[target % 10] = i;
		order /= 10;
		target /= 10;
	}

	for (int i = 1; i <= 8; i++) {
		num += abs(cur[i] / 3 - tar[i] / 3) + abs(cur[i] % 3 - tar[i] % 3);//位置移动值应该是 |xc-xt|+|yc-yt|
	}
	return num;
}

//启发函数2，原理：返回逆序数目*4
int H2(int curOrder)
{   
	int num = 0;
	twoD_arr curr;
	OneD_TwoD(curOrder, curr);
	for (int i = 0; i < 9; i++) {
		for (int j = i + 1; j < 9; j++)
		{
			if ((curr[i / 3 + 1][i % 3 + 1] != 0) && (curr[j / 3 + 1][j % 3 + 1] != 0)
				&& (curr[i / 3 + 1][i % 3 + 1] > curr[j / 3 + 1][j % 3 + 1]))
				++num;
		}
	}
	return num * 3;
}

//启发函数3，原理：H和H2之和
int H3(int curOrder, int tarOrder) {
	return (H(curOrder, tarOrder) + H2(curOrder));
}

//递归寻找子节点（不断返回父节点）
void fundtree(int parent, int size) {
	if (size == -1) {
		return;
	}
	else if (size == 0) {
		FILE* fp;
		fp = fopen("out_tree.txt", "a");
		void(fprintf(fp, "%c %d ", '<', route[size].order));
		fclose(fp);
		return;
	}
	for (int i = size; i >= 0; i--) {
		//找到route中原结点的parent结点，递归调用函数，输出结果
		if (route[i].order == parent) fundtree(route[i].parent, i);
	}
	FILE* fp;
	fp = fopen("out_tree.txt", "a");
	void(fprintf(fp, "%d ", route[size].order));
	fclose(fp);
}

//调用fundtree打印祖先节点，后打印当前节点值
void maketree() {
	for (int i = 0; i < route.size(); i++) {
		fundtree(route[i].parent, i);
		FILE* fp;
		fp = fopen("out_tree.txt", "a");
		void(fprintf(fp, "%c ", '>'));
		if (route[i].oneD_arr > 100000000)
			void(fprintf(fp, "%d ", route[i].oneD_arr));
		else
			void(fprintf(fp, "%d%d ", 0, route[i].oneD_arr));
		void(fprintf(fp, "%c %d %c\n", '*', Func(route[i]), '*'));//f=g+h
		expansion.push_back(route[i].parent);//将结点的具体结构放入route中
		sum_node++;
		fclose(fp);
	}
}


/*运行open算法:
open表和close表中的元素在一定规则下可以相互转化，最终搜到解
1：对于新添加的节点S（open表和close表中均没有这个状态），S直接添加到open表中
2：对于已经添加的节点S（open表和close表中已经有这个状态），若在open表中，与原来状态S0的f（n）比较，取最小的一个若在close表中，那就分成两种情况，
第一种，close表中的状态S0的f（n）大于S的，不做修改；第二种，S0的f（n）小于S的，那就需要将close表中的S0的f（n）更新，同时将该状态移入到open表中
3：下一个搜索节点的选择问题，选取open表中f（n）值最小的状态作为下一个待搜索节点
4：每次需要将待搜索的节点下一个所有的状态按照规则1和2更新open表，close表，搜索完节点后，移到close表中
，返回值取最短路径的step值*/
int body(const int& first, const int& last) {
	if (!achievable(first, last))//检测是否可实施
		return -1;

	//清理上次运行时产生的痕迹
	open_table.clear();
	table_open.clear();
	closed_table.clear();
	route.clear();

	//序号值，递增，以查询parent的序号
	int index = 0;
	if (way == 3) {
		//初始化头结点,其parent序号是-1，表示不存在
		DigitNode start(first, 0, H3(first, last), index++, -1);
		//将头结点放入两个open表中
		open_table.insert(make_pair<int, DigitNode>(int(H3(first, last)), DigitNode(start)));
		table_open.insert(make_pair<DigitNode, int>(DigitNode(start), int(H3(first, last))));
	}

	else if (way == 2) {
		//初始化头结点,其parent序号是-1，表示不存在
		DigitNode start(first, 0, H2(first), index++, -1);
		//将头结点放入两个open表中
		open_table.insert(make_pair<int, DigitNode>(int(H2(first)), DigitNode(start)));
		table_open.insert(make_pair<DigitNode, int>(DigitNode(start), int(H2(first))));
	}

	else if (way == 1) {
		//初始化头结点,其parent序号是-1，表示不存在
		DigitNode start(first, 0, H1(first, last), index++, -1);
		//将头结点放入两个open表中
		open_table.insert(make_pair<int, DigitNode>(int(H1(first, last)), DigitNode(start)));
		table_open.insert(make_pair<DigitNode, int>(DigitNode(start), int(H1(first, last))));
	}

	else {
		//初始化头结点,其parent序号是-1，表示不存在
		DigitNode start(first, 0, H(first, last), index++, -1);
		//将头结点放入两个open表中
		open_table.insert(make_pair<int, DigitNode>(int(H(first, last)), DigitNode(start)));
		table_open.insert(make_pair<DigitNode, int>(DigitNode(start), int(H(first, last))));
	}
	//进行启发式搜索
	while (open_table.size())
	{
		//取出open表的第一个元素，即评估函数值最小的结点进行扩展
		DigitNode preNode = open_table.begin()->second;
		//cout << preNode.order << ' ' << preNode.parent << endl;

		//从open表中清除,并将序列放入closed_table表中，具体的结构值放入route中
		open_table.erase(open_table.begin());                   
		table_open.erase(table_open.lower_bound(preNode));  
		closed_table.insert(make_pair<int, bool>(int(preNode.oneD_arr), bool(true)));
		route.push_back(preNode);//将结点的具体结构放入route中

		//如果是已到达目标，返回最短路径值
		if (final(preNode.oneD_arr, last)) {
			maketree();
			return preNode.d;
		}
		expansion_node++;
		//接下来是对取出的结点形成新的子节点进行操作
		//寻找0的位置
		int zero_x = -1, zero_y = -1;//zero_x，zero_y代表空格的坐标[zero_x,zero_y]
		twoD_arr tmpTwoD;int tmpOneD;//临时一维数组和二维数组
		OneD_TwoD(preNode.oneD_arr, tmpTwoD);
		for (int i = 1; i <= 3; i++) {
			if (zero_x != -1) 
				break;
			for (int j = 1; j <= 3; j++) {
				if (tmpTwoD[i][j] == 0)
				{
					zero_x = i;
					zero_y = j;
					break;
				}
			}
		}
		
		//通过移动,生成子结点
		for (int k = 0; k < 4; k++) {
			static int x_move[] = { -1,0,1,0 };  //左移是-1,右移是+1
			static int y_move[] = { 0,1,0,-1 };  //上移是+1,下移是-1
			int after_x = zero_x + x_move[k]; //移动后0的x坐标
			int after_y = zero_y + y_move[k]; //移动后0的y坐标
			//对新生成的子节点进行判定，是否入open表中的判定结束
			if (after_x >= 1 && after_x <= 3 && after_y >= 1 && after_y <= 3)//需要保证移动后的0不越界
			{
				swap(tmpTwoD[zero_x][zero_y], tmpTwoD[after_x][after_y]);//将原来空格和移动后的0应在的位置的元素，交换顺序
				tmpOneD = TwoD_OneD(tmpTwoD);  //提取出新生成的状态序列一维值
				swap(tmpTwoD[zero_x][zero_y], tmpTwoD[after_x][after_y]);//序列还原，用于0其他位置的移动

				//对新的子节点进行判定是否能放入open表中
				int tempH;
				if (way == 3) {
					tempH = H3(tmpOneD, last);
				}
				else if (way == 2) {
					tempH = H2(tmpOneD);
				}

				else if (way == 1) {
					tempH = H1(tmpOneD, last);
				}
				else {
					tempH = H(tmpOneD, last);
				}

				DigitNode newNode(tmpOneD, preNode.d + 1, tempH, index++, preNode.order);//初始化新生成的子节点
				int newFunc = Func(newNode);//f用判定函数f=g+h求得，保存新结点的Func值
				//新生成的子节点的一维序列是tmpOneD,深度是父节点preNode的深度+1
				//序列号index按序+1，父节点序列号是preNode的序列号


				//查找新生成结点的oneD_arr是否在closed_table表中
				if (!closed_table.count(tmpOneD))//如果不在closed_table表中，执行以下操作
				{
					//查找新生成结点的oneD_arr是否在open表中
					//在值键表中，first的值从小到大的排列顺序是新类型DigitNode的比较大小的过程
					map<DigitNode, int>::iterator ptr_1 = table_open.lower_bound(newNode); //迭代器(iterator)是一中检查容器内元素并遍历元素的数据类型
					//ptr_1指针指向oneD_arr值>=newNode的迭代器元素，如果该元素的first值恰好为newNode,说明newNode的序列值oneD_arr在open表中存在

					map<int, DigitNode>::iterator ptr_2;//创建指向键值表迭代器的指针ptr_2
					//如果在open表中
					if (ptr_1 != table_open.end() && ptr_1->first.oneD_arr == newNode.oneD_arr) {
						//如果新生成的结点是相对于原open表中结点的最优解
						if (newFunc < Func(ptr_1->first)) {
							for (ptr_2 = open_table.lower_bound(Func(ptr_1->first)); ptr_2 != open_table.upper_bound(Func(ptr_1->first)); ++ptr_2)
								if (ptr_2->second.oneD_arr == newNode.oneD_arr) 
									break;
							//删除原有open表中结点
							open_table.erase(ptr_2);
							table_open.erase(ptr_1);
							//将新结点加入open表中
							open_table.insert(make_pair<int, DigitNode>(int(newFunc), DigitNode(newNode)));
							table_open.insert(make_pair<DigitNode, int>(DigitNode(newNode), int(newFunc)));
						}
					 //不是最优解，放弃新的子结点
					}

					//若既不在open表中，也不在closed_table表中
					else {
						//将新结点加入open表中
						open_table.insert(make_pair<int, DigitNode>(int(newFunc), DigitNode(newNode)));
						table_open.insert(make_pair<DigitNode, int>(DigitNode(newNode), int(newFunc)));
					}
				}

				//如果在closed_table表中，执行以下操作
				else if (closed_table.count(tmpOneD))  
				{
					//查找到closed_table表里的具体结构route中保存的旧DigitNode，比较func值，是否有更优解
					int locate;
					for (locate = 0; locate < route.size(); locate++) {
						if (route[locate].oneD_arr== newNode.oneD_arr) break;//DigitNode类型的==号代表oneD_arr值相同
					}
					//如果是优解
					if (newFunc < Func(route[locate]) && (route[locate].oneD_arr == tmpOneD)) {
						//将原closed_table表中的元素删除，将新结点放入open表中
						closed_table.erase(closed_table.lower_bound(newNode.oneD_arr));
						route.erase(route.begin() + locate);
						//将新结点加入open表中
						open_table.insert(make_pair<int, DigitNode>(int(newFunc), DigitNode(newNode)));
						table_open.insert(make_pair<DigitNode, int>(DigitNode(newNode), int(newFunc)));
					}
					//如果不是优解，舍弃新的子结点
				}
			
			}
		}

	}
	//open表为空，无解，返回-1
	return -1;
}

//将文件中的目标状态和初始状态输入二维数组
void inPut(twoD_arr s) {
	for (int i = 1; i <= 3; i++) {
		for (int j = 1; j <= 3; j++) {
			cin >> s[i][j];
		}
	}
}


void findRoute(int parent, int size, int step) {
	if (step == -1) {
		return;
	}
	else if (step == 0) {
		FILE* fp;
		fp = fopen("out.txt", "a");
		void(fprintf(fp, "%d ", route[size].order));
		fclose(fp);
		return;
	}
	for (int i = size; i >= 0; i--) {
		//找到route中原结点的parent结点，递归调用函数，输出结果
		if (route[i].order == parent) findRoute(route[i].parent, i, step - 1);
	}
	FILE* fp;
	fp = fopen("out.txt", "a");
	void(fprintf(fp, "%d ", route[size].order));
	fclose(fp);
}


int main() {
	twoD_arr first, last;//初始和目标状态
	void(freopen("in.txt", "r+",stdin));
	cin >> way;
	if (!(way == 0 || way == 1 || way == 2 || way == 3))
		exit(-1);
	inPut(first);//初始状态放入二维数组first
	inPut(last);//目标状态放入二维数组last
	fclose(stdin);
	int step = body(TwoD_OneD(first), TwoD_OneD(last));
	if (step != -1)
	{
		cout << "有解"  << endl;
		findRoute((route.end() - 1)->parent, route.size() - 1, step);
		FILE* fp;
		fp = fopen("out.txt", "a");
		void(fprintf(fp, " %c", '>'));
		fclose(fp);
		FILE* fp2;
		fp2 = fopen("node.txt", "a");
		expansion = unique_element_in_vector(expansion);//扩展节点表去重
		void(fprintf(fp2, " %d %d%c", expansion.size()-1,sum_node,'>'));
		fclose(fp2);
	}
	else {
		cout << "不可达" << endl;
		FILE* fp;
		fp = fopen("out.txt", "a");
		void(fprintf(fp, " %d", -1));
		fclose(fp);
	}
	return 0;
}

